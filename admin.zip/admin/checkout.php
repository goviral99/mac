<?php
include_once('functions.php');

if (isset($_POST['i_type'])) {
    $cause_array = array('Orphan Sponsorship', 'Refugees Reliefs', 'Water Wells', 'Zakat');
    // if (in_array($_SESSION['cause'], $cause_array)) {
    // } else {
    //     $_SESSION['statusMsg'] = 'Select Donate Cause';
    //     header('Location: '.website_url);
    // die();
    // }
    
    
    if (!function_exists('str_contains')) {
        function str_contains(string $haystack, string $needle): bool
        {
            return '' === $needle || false !== strpos($haystack, $needle);
        }
    }

    $_SESSION['i_type'] = $_POST['i_type'];

    $total_amount =  0;
    foreach ($_POST['i_type'] as $key => $value) {
        $v = str_replace(' ', '_', $value);
        if (!empty($_POST[$v][1])) {
            if (str_contains($_POST[$v][1], 'Orphan') || str_contains($value, 'Orphan')) {
                $_POST[$v][1] = str_replace('Orphans', '', $_POST[$v][1]);
                $_POST[$v][1] = str_replace('Orphan', '', $_POST[$v][1]);
                if ($_POST['g_opts'] == 0 || $_POST['g_opts'] == 2) {
                    $_POST[$v][1] = (int)$_POST[$v][1];
                    $_POST[$v][1]= $_POST[$v][1] * 840;
                    $_POST[$v][1] = (int)$_POST[$v][1];
                }
                if ($_POST['g_opts'] == 1) {
                    $_POST[$v][1] = (int)$_POST[$v][1];
                    $_POST[$v][1]= $_POST[$v][1] * 70;
                    $_POST[$v][1] = (int)$_POST[$v][1];
                }
            }
            $total_amount =  $total_amount + $_POST[$v][1];
            $_SESSION['cause'][$value] = $_POST[$v][1];
        } else {
            if (str_contains($_POST[$v][0], 'Orphan')) {
                $_POST[$v][0] = str_replace('Orphans', '', $_POST[$v][0]);
                $_POST[$v][0] = str_replace('Orphan', '', $_POST[$v][0]);
                if ($_POST['g_opts'] == 0 || $_POST['g_opts'] == 2) {
                    $_POST[$v][0] = (int)$_POST[$v][0];
                    $_POST[$v][0] = $_POST[$v][0] * 840;
                    $_POST[$v][0] = (int)$_POST[$v][0];
                }
                if ($_POST['g_opts'] == 1) {
                    $_POST[$v][0] = (int)$_POST[$v][0];
                    $_POST[$v][0] = $_POST[$v][0] * 70;
                    $_POST[$v][0] = (int)$_POST[$v][0];
                }
            }            
            $total_amount =  $total_amount + $_POST[$v][0];
            $_SESSION['cause'][$value] = $_POST[$v][0];
        }  
    }
    
    $_SESSION['payment'] = $total_amount;
    $_SESSION['g_opts'] = $_POST['g_opts'];
    // if ($_POST['p_opts'] == 0) {
    //     $_SESSION['payment'] = $_POST['p_opts_other'];
    // } else {
    //     $_SESSION['payment'] = $_POST['p_opts'];
    // }    
} elseif (isset($_SESSION['payment'])) {
    
} else {
    session_destroy();
    header('Location: '.website_url);
    die();
}

if ($_SESSION['payment'] == 0) {
    $_SESSION['statusMsg'] = 'Please select amount for donation';
    header('Location: '.website_url);
    die();
}

$frequency = '';
if ($_SESSION['g_opts'] == 0) {
    $frequency = 'one-time';
}
if ($_SESSION['g_opts'] == 1) {
    $frequency = 'monthly';
}
if ($_SESSION['g_opts'] == 2) {
    $frequency = 'yearly';
}
// echo "<pre>"; print_r($_POST['i_type']); die("</pre>");

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="includes/images/Logo.png">
        <title></title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <style type="text/css">
            input.field_error {
                border-color: red !important;
            }
        </style>
        
               <footer class="py-5 py-md-4">
            <div class="container">
                <div class="d-md-flex justify-content-between align-items-center">
                    <a href="http://handsforcharity.org/">
                        <img src="includes/images/Logo.png" class="img-fluid" alt="logo">
                    </a>
                    <ul class="list-unstyled mt-3 mt-md-0 mb-0 footer_social_icons d-flex align-items-center">
                        <li>
                            <a href="https://www.linkedin.com/company/hands4charity/" class="d-flex align-items-center justify-content-center">
                               <svg fill="#1f92c8" xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 30 30" width="60px" height="60px">    <path d="M15,3C8.373,3,3,8.373,3,15c0,6.627,5.373,12,12,12s12-5.373,12-12C27,8.373,21.627,3,15,3z M10.496,8.403 c0.842,0,1.403,0.561,1.403,1.309c0,0.748-0.561,1.309-1.496,1.309C9.561,11.022,9,10.46,9,9.712C9,8.964,9.561,8.403,10.496,8.403z M12,20H9v-8h3V20z M22,20h-2.824v-4.372c0-1.209-0.753-1.488-1.035-1.488s-1.224,0.186-1.224,1.488c0,0.186,0,4.372,0,4.372H14v-8 h2.918v1.116C17.294,12.465,18.047,12,19.459,12C20.871,12,22,13.116,22,15.628V20z"/></svg>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/hands4charity" class="d-flex align-items-center justify-content-center">
                                <svg width="14" height="24" viewBox="0 0 14 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M3.4 23V14.4H1V9.5H3.4V7.1C3.4 3.7 6.1 1 9.5 1H13.2V5.9H10.8C9.4 5.9 8.4 7 8.4 8.3V9.5H13.3L12 14.4H8.3V23H3.4Z" fill="#0092C8" stroke="#0092C8" stroke-linejoin="round"/>
                                </svg>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.youtube.com/channel/UCqXuNEB0D9mYdGrhgb_gE2Q" class="d-flex align-items-center justify-content-center">
                                <svg  xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                      width="27px" height="20px" viewBox="0 0 27 20" enable-background="new 0 0 27 20" xml:space="preserve">
                                <path fill="#0092C8" d="M12.209,0h1.996h0.822C25.122,0.118,26.883,1.657,27,9.112v0.828v0.947C26.883,18.698,25.004,20,13.735,20
                                      h-1.644h-1.174C1.643,19.882,0.117,18.225,0,10.533V9.586V8.994C0.235,1.42,2.113,0.118,12.209,0z M11.27,6.509v7.101l5.869-3.55
                                      L11.27,6.509z"/>
                                </svg>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/hands4charity/" class="d-flex align-items-center justify-content-center">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19 0.5C21.5 0.5 23.5 2.5 23.5 5V19C23.5 21.5 21.5 23.5 19 23.5H5C2.5 23.5 0.5 21.5 0.5 19V5C0.5 2.5 2.5 0.5 5 0.5H19ZM12 5.8C8.5 5.8 5.8 8.6 5.8 12C5.8 15.5 8.6 18.2 12 18.2C15.5 18.2 18.2 15.4 18.2 12C18.2 8.5 15.5 5.8 12 5.8ZM12 7.2C14.6 7.2 16.8 9.3 16.8 12C16.8 14.6 14.7 16.8 12 16.8C9.4 16.8 7.2 14.7 7.2 12C7.2 9.4 9.4 7.2 12 7.2ZM19 3.5C18.2 3.5 17.5 4.2 17.5 5C17.5 5.8 18.2 6.5 19 6.5C19.8 6.5 20.5 5.8 20.5 5C20.5 4.2 19.8 3.5 19 3.5Z" fill="#0092C8"/>
                                </svg>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </footer>

        <div class="container py-4 pt-md-5 w-100">
            <div class="row">
                <div class="col-md-8 checkout_form">
                    
                    <h1 class="mainTitle mt-3 mb-2 text-center">$<?php echo $_SESSION['payment'] ?> (<?php echo $frequency ?>)</h1>
                    <div class="row justify-content-center">
                        <div class="col-md-7">
                            <p class="text-center">
                                Thank you for your generosity. 
                            </p>
                        </div>
                    </div>
                </div>
                <?php if (!empty($_SESSION['statusMsg'])) {
                    ?>
                    <div class="col-12">
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                            width="24px" height="24px" viewBox="-3.994 -4 24 24" enable-background="new -3.994 -4 24 24" xml:space="preserve">
                            <path fill="#664D03" d="M8,19.942c6.595,0,11.942-5.347,11.942-11.942S14.595-3.942,8-3.942S-3.942,1.405-3.942,8
                            S1.405,19.942,8,19.942z M9.388,5.892l-1.493,7.023c-0.104,0.508,0.043,0.796,0.454,0.796c0.29,0,0.727-0.104,1.024-0.367
                            l-0.131,0.621c-0.428,0.516-1.373,0.893-2.187,0.893c-1.049,0-1.496-0.63-1.206-1.969l1.102-5.177
                            C7.046,7.275,6.96,7.116,6.522,7.01L5.849,6.889l0.122-0.569L9.39,5.892L9.388,5.892z M8,4.268c-0.824,0-1.493-0.668-1.493-1.493
                            S7.176,1.283,8,1.283s1.493,0.668,1.493,1.493S8.824,4.268,8,4.268z"/>
                        </svg>
                            <?php echo $_SESSION['statusMsg'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    </div>
                    <?php
                    $_SESSION['statusMsg'] = '';
                } ?>
                <div class="col-md-8 checkout_form">
                    <form action="payment.php" method="post" id="payment_form">
                        <h5 class="mb-3"><b>Payment Method</b></h5>
                        <nav>
                            <div class="nav nav-tabs row payment_tabs mb-4" id="nav-tab" role="tablist">
                                <button class="col-md mb-3 mb-md-0 nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">
                                    <div class="i_input_inner">
                                        <input id="i_type1" type="radio" name="p_type" value="cc" checked>
                                        <label for="i_type1" class="d-flex p-2 align-items-center" data-img-url="includes/images/img1.jpg">
                                            Credit Card
                                        </label>
                                    </div>
                                </button>

                                <?php if ($_SESSION['g_opts'] == 0 ): ?>
                                <button class="col-md mb-3 mb-md-0 nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">
                                    <div class="i_input_inner">
                                        <input id="i_type2" type="radio" name="p_type" value="gp">
                                        <label for="i_type2" class="d-flex p-2 align-items-center" data-img-url="includes/images/img2.jpg">
                                            Google/Apple Pay
                                        </label>
                                    </div>
                                </button>
                                <?php endif ?>


                                <button class="col-md nav-link" id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="false">
                                    <div class="i_input_inner">
                                        <input id="i_type3" type="radio" name="p_type" value="pp">
                                        <label for="i_type3" class="d-flex p-2 align-items-center" data-img-url="includes/images/img3.jpg">
                                            PayPal
                                        </label>
                                    </div>
                                </button>

                            </div>
                        </nav>
                    
                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab" tabindex="0">
                                <h5 class="mb-3"><b>Credit Card Information</b></h5>
                                <div class="row mb-3 mb-md-4">
                                    <div class="form-group col-md-12 mb-3 mb-md-4">
                                        <div class="position-relative">
                                            <img src="includes/images/frame.png" class="img-fluid" alt="">
                                            <input type="text" class="form-control" name="co_chn" placeholder="Card Holder Name">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-5 mb-3 mb-md-4">
                                        <div class="position-relative">
                                            <img src="includes/images/cards.png" class="img-fluid" alt="">
                                            <div id="co_cn" ></div>
                                        </div>
                                        <div id="co_cn_response"></div>
                                        <!-- <input type="text" class="form-control" name="co_cn" placeholder="Card number"> -->
                                    </div>
                                    <div class="form-group col-md-4 mb-3 mb-md-4">
                                        <div class="position-relative">
                                            <img src="includes/images/stickynote.png" class="img-fluid" alt="">
                                            <div id="co_my"></div>
                                        </div>
                                        <div id="co_my_response"></div>
                                    </div>
                                    <div class="form-group col-md-3 mb-3 mb-md-4">
                                        <div class="position-relative">
                                            <img src="includes/images/key.png" class="img-fluid" alt="">
                                            <div id="co_cw"></div>
                                        </div>
                                        <div id="co_cw_response"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" tabindex="0">
                                <div id="payment-request-button">
                                    <!-- A Stripe Element will be inserted here. -->
                                </div>
                            </div>
                            <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab" tabindex="0">

                            </div>
                        </div>
                        <div class="checkout_form_details">
                            <h5 class="mb-3"><b>Your Details</b></h5>
                            <div class="row mb-md-4">
                                <div class="form-group col-md-6 mb-3 mb-md-4">
                                    <div class="position-relative">
                                        <img src="includes/images/frame.png" class="img-fluid" alt="">
                                        <input type="text" class="form-control" name="co_fname" placeholder="First name" required>
                                    </div>
                                </div>
                                <div class="form-group col-md-6 mb-3 mb-md-4">
                                    <div class="position-relative">
                                        <img src="includes/images/frame.png" class="img-fluid" alt="">
                                        <input type="text" class="form-control" name="co_lname" placeholder="Last name" required>
                                    </div>
                                </div>
                                <div class="form-group col-md-6 mb-3 mb-md-4">
                                    <div class="position-relative">
                                        <img src="includes/images/sms.png" class="img-fluid" alt="">
                                        <input type="email" class="form-control" name="co_email" placeholder="Email *" required>
                                    </div>
                                </div>
                                <div class="form-group col-md-6 mb-3 mb-md-4">
                                    <div class="position-relative">
                                        <img src="includes/images/call-calling.png" class="img-fluid" alt="">
                                        <input type="text" class="form-control" name="co_phone" placeholder="Phone *">
                                    </div>
                                </div>
                                <div class="form-group col-md-12 mb-3 mb-md-4">
                                    <div class="position-relative">
                                        <img src="includes/images/company.png" class="img-fluid" alt="">
                                        <input type="text" class="form-control" name="co_org" placeholder="Organization/Company">
                                    </div>
                                </div>
                                <div class="form-group col-md-12 mb-3 mb-md-4">
                                    <div class="position-relative">
                                        <img src="includes/images/location.png" class="img-fluid" alt="">
                                        <input type="text" class="form-control" name="co_address1" placeholder="Address line 1">
                                    </div>
                                </div>
                                <div class="form-group col-md-12 mb-3 mb-md-4">
                                    <div class="position-relative">
                                        <img src="includes/images/location.png" class="img-fluid" alt="">
                                        <input type="text" class="form-control" name="co_address2" placeholder="Address line 2">
                                    </div>
                                </div>
                                <div class="form-group col-md-6 mb-3 mb-md-4">
                                    <div class="position-relative">
                                        <img src="includes/images/global.png" class="img-fluid" alt="">
                                        <input type="text" class="form-control" name="co_country" placeholder="Country">
                                    </div>
                                </div>
                                <div class="form-group col-md-6 mb-3 mb-md-4">
                                    <div class="position-relative">
                                        <img src="includes/images/map.png" class="img-fluid" alt="">
                                        <input type="text" class="form-control" name="co_city" placeholder="City">
                                    </div>
                                </div>
                                <div class="form-group col-md-6 mb-3 mb-md-4">
                                    <div class="position-relative">
                                        <img src="includes/images/flag-2.png" class="img-fluid" alt="">
                                        <input type="text" class="form-control" name="co_state" placeholder="Province/State">
                                    </div>
                                </div>
                                <div class="form-group col-md-6 mb-3 mb-md-4">
                                    <div class="position-relative">
                                        <img src="includes/images/password-check.png" class="img-fluid" alt="">
                                        <!-- <div id="co_zip"></div> -->
                                        <input type="text" class="form-control" name="co_zip" placeholder="Postal Code / Zip">
                                    </div>
                                    <!-- <div id="co_zip_response"></div> -->
                                </div>
                            </div>
                            <div class="form-check mb-4">
                                <input class="form-check-input" type="checkbox" value="1" name="app_fee" id="app_fee">
                                <label class="form-check-label" for="app_fee">
                                    <p>I'll cover the processing fee - add it to my donation</p>
                                </label>
                            </div>
                           <hr>
                            <div class="form-check ps-0">
                                <?php
                                foreach ($_SESSION['i_type'] as $key => $value) {
                                    $v = str_replace('_', ' ', $value);
                                            // echo "<pre>"; print_r($_SESSION); die("</pre>");
    
                                    if (!empty($_SESSION['cause'][$v])) {
                                        ?>
                                        <label class="form-check-label my-3 d-flex align-items-center justify-content-between">
                                            <b><?php echo $value ?></b>
                                            <b>
                                                $<?php echo $_SESSION['cause'][$v]?>
                                            </b>
                                        </label>
                                        <?php
                                    } else { ?>
                                        <label class="form-check-label my-3 d-flex align-items-center justify-content-between">
                                            <b><?php echo $value ?></b>
                                            <b>
                                                $<?php echo $_SESSION['cause'][$v]?>
                                            </b>
                                        </label>
                                    <?php }
                                }                                    
                                ?>
                            </div>
                            <hr>
                            <div class="d-flex align-items-center justify-content-between">
                                <div>
                                    <p>Subtotal</p>
    
                                    <b>Total</b>
                                </div>
                                <div>
                                    <p>$<span class="total_val"><?php echo $_SESSION['payment'] ?></span></p>
    
                                    <b>$<span class="total_val"><?php echo $_SESSION['payment'] ?></span></b>
                                </div>
                                <input type="hidden" name="selected_payment" value="<?php echo $_SESSION['payment'] ?>">
                                <input type="hidden" name="total_payment" value="<?php echo $_SESSION['payment'] ?>">
                            </div>
                            <div id="paymentError">
                            </div>
                            <div class="text-center my-4">
                                <button type="submit" class="btn py-2 submit_Form" id="donate-btn">Donate </button>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="col-md-4">
                    <div class="checkout_info_right p-4">
                        <?php
                        if (isset($_SESSION['i_type'])) {
                            foreach ($_SESSION['i_type'] as $key => $value) { 
                                ?>
                                <b>Program: <?php echo $key + 1 ?></b>
                                <p><?php echo $value ?></p>
                                <b>Frequency:</b>
                                <p class="mb-0"><?php echo $frequency; ?></p>
                                <?php if (count($_SESSION['i_type']) > $key + 1): ?>
                                    <hr>
                                <?php endif ?>
                                <?php
                            }   
                        }
                        ?>
                        <!-- <b>Program:</b>
                        <p>
                            <?php echo $_SESSION['cause'] ?>
                        </p>
                        <b>
                            Cause:
                        </b>
                        <p>
                            Where Most Needed
                        </p>
                        <b>
                            Frequency:
                        </b>
                        <p>
                            <?php echo $frequency ?>
                        </p>
                        <b>
                            Donation Breakdown:
                        </b>
                        <p>
                            $<?php echo $_SESSION['payment'] ?>
                        </p> -->
                    </div>
                </div>
            </div>
        </div>
        <footer class="py-5 py-md-4">
            <div class="container">
                <div class="d-md-flex justify-content-between align-items-center">
                    <a href="https://handsforcharity.org/">
                        <img src="includes/images/Logo.png" class="img-fluid" alt="logo">
                    </a>
                   <ul class="list-unstyled mt-3 mt-md-0 mb-0 footer_social_icons d-flex align-items-center">
                        <li>
                            <a href="https://www.linkedin.com/company/hands4charity/" class="d-flex align-items-center justify-content-center">
                               <svg fill="#1f92c8" xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 30 30" width="100px" height="100px">    <path d="M15,3C8.373,3,3,8.373,3,15c0,6.627,5.373,12,12,12s12-5.373,12-12C27,8.373,21.627,3,15,3z M10.496,8.403 c0.842,0,1.403,0.561,1.403,1.309c0,0.748-0.561,1.309-1.496,1.309C9.561,11.022,9,10.46,9,9.712C9,8.964,9.561,8.403,10.496,8.403z M12,20H9v-8h3V20z M22,20h-2.824v-4.372c0-1.209-0.753-1.488-1.035-1.488s-1.224,0.186-1.224,1.488c0,0.186,0,4.372,0,4.372H14v-8 h2.918v1.116C17.294,12.465,18.047,12,19.459,12C20.871,12,22,13.116,22,15.628V20z"/></svg>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/hands4charity" class="d-flex align-items-center justify-content-center">
                                <svg width="14" height="24" viewBox="0 0 14 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M3.4 23V14.4H1V9.5H3.4V7.1C3.4 3.7 6.1 1 9.5 1H13.2V5.9H10.8C9.4 5.9 8.4 7 8.4 8.3V9.5H13.3L12 14.4H8.3V23H3.4Z" fill="#0092C8" stroke="#0092C8" stroke-linejoin="round"/>
                                </svg>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.youtube.com/channel/UCqXuNEB0D9mYdGrhgb_gE2Q" class="d-flex align-items-center justify-content-center">
                                <svg  xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                      width="27px" height="20px" viewBox="0 0 27 20" enable-background="new 0 0 27 20" xml:space="preserve">
                                <path fill="#0092C8" d="M12.209,0h1.996h0.822C25.122,0.118,26.883,1.657,27,9.112v0.828v0.947C26.883,18.698,25.004,20,13.735,20
                                      h-1.644h-1.174C1.643,19.882,0.117,18.225,0,10.533V9.586V8.994C0.235,1.42,2.113,0.118,12.209,0z M11.27,6.509v7.101l5.869-3.55
                                      L11.27,6.509z"/>
                                </svg>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/hands4charity/" class="d-flex align-items-center justify-content-center">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19 0.5C21.5 0.5 23.5 2.5 23.5 5V19C23.5 21.5 21.5 23.5 19 23.5H5C2.5 23.5 0.5 21.5 0.5 19V5C0.5 2.5 2.5 0.5 5 0.5H19ZM12 5.8C8.5 5.8 5.8 8.6 5.8 12C5.8 15.5 8.6 18.2 12 18.2C15.5 18.2 18.2 15.4 18.2 12C18.2 8.5 15.5 5.8 12 5.8ZM12 7.2C14.6 7.2 16.8 9.3 16.8 12C16.8 14.6 14.7 16.8 12 16.8C9.4 16.8 7.2 14.7 7.2 12C7.2 9.4 9.4 7.2 12 7.2ZM19 3.5C18.2 3.5 17.5 4.2 17.5 5C17.5 5.8 18.2 6.5 19 6.5C19.8 6.5 20.5 5.8 20.5 5C20.5 4.2 19.8 3.5 19 3.5Z" fill="#0092C8"/>
                                </svg>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </footer>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://js.stripe.com/v3/"></script>
        <script>
            var stripe = Stripe('pk_test_51KrzE2BwNF8aAhcXNMoFjTtRn2nyHynf61jKNUDmzmSQYNXQAQGPLFol3iNsKmB5VTnrZL1wvxQoXzhAqO5ygqGs00wJghjunP', {
                apiVersion: "2020-08-27",
            });
            
            <?php
            $cause = '';

            $counter = 1;
            foreach ($_SESSION['cause'] as $key => $value) {
                $key = str_replace(' ', '', $key);
                $cause = $cause.$key;
                if ($counter < count($_SESSION['cause'])) {
                    $cause = $cause.'_';
                }
                $counter = $counter + 1;
            }
            $gpay_amout = $_SESSION['payment'] * 100;
            $gpay_amout =  (int)$gpay_amout;
            ?>

            var paymentRequest = stripe.paymentRequest({
                country: 'CA',
                currency: 'cad',
                total: {
                    label: '<?php echo $cause ?>',
                    amount: <?php echo  $gpay_amout?>,
                },
                requestPayerName: true,
                requestPayerEmail: true,
            });
            var elements = stripe.elements();
            var prButton = elements.create('paymentRequestButton', {
                paymentRequest: paymentRequest,
                style: {
                    paymentRequestButton: {
                        type: 'donate',
                        theme: 'dark',
                        height: '40px'
                    },
                },
            });

            paymentRequest.canMakePayment().then(function (result) {
                console.log(result);
                if (result) {
                    prButton.mount('#payment-request-button');
                } else {
                    document.getElementById('payment-request-button').style.display = 'none';
                }
            });

            paymentRequest.on('paymentmethod', function (ev) {
                stripe.confirmCardPayment(
                    clientSecret,
                    {payment_method: ev.paymentMethod.id},
                    {handleActions: false}
                    ).then(function (confirmResult) {
                        if (confirmResult.error) {
                            ev.complete('fail');
                        } else {
                            ev.complete('success');
                            if (confirmResult.paymentIntent.status === "requires_action") {
                                stripe.confirmCardPayment(clientSecret).then(function (result) {
                                    if (result.error) {
                                    } else {
                                    }
                                });
                            } else {
                            }
                        }
                    });
                });
        </script>
        <!--<script src="includes/js/googlepay.js"></script>-->
        <script src="includes/js/custom.js"></script>
        <script src="includes/js/fix.js"></script>
        <script>
            $('.payment_tabs input[name="p_type"]').on('change', function(event) {
                event.preventDefault();
                if ($(this).val() == 'gp') {
                    $('.checkout_form_details').css({
                        'display': 'none',
                    });
                } else {
                    $('.checkout_form_details').css({
                        'display': 'block',
                    });
                }
            });
        </script>
    </body>
</html>