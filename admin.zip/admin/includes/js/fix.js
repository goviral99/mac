var donate = document.getElementById('donate-btn');

var form = document.getElementById('payment_form');

// form[7].on('change', function(event) {
//     console.log(event);
// });
// form[8].on('change', function(event) {
//     console.log(event);
// });
// form[9].on('change', function(event) {
//     console.log(event);
// });

// elements.fetchUpdates()
//   .then(function(result) {
//     console.log(result);
//   });

donate.addEventListener("click", () => {
    
    // donate.disabled = true;
    
})