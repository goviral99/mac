<?php 
	include_once('functions.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="includes/images/smalllogo.png">
	<title></title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="style.css">
</head>
<body>


	<div class="mainFormWrap mh-100 d-md-flex align-items-center position-relative">
		<div class="container w-100">
			<div class="row">
			<div class="col-md-6 py-4">
				<?php if (!empty($_SESSION['statusMsg'])): ?>
					<div class="mb-0">
						<div class="alert alert-warning alert-dismissible fade show" role="alert">
							<svg x="0px" y="0px" width="24px" height="24px" viewBox="-3.994 -4 24 24" enable-background="new -3.994 -4 24 24" xml:space="preserve">
								<path fill="#664D03" d="M8,19.942c6.595,0,11.942-5.347,11.942-11.942S14.595-3.942,8-3.942S-3.942,1.405-3.942,8
								S1.405,19.942,8,19.942z M9.388,5.892l-1.493,7.023c-0.104,0.508,0.043,0.796,0.454,0.796c0.29,0,0.727-0.104,1.024-0.367
								l-0.131,0.621c-0.428,0.516-1.373,0.893-2.187,0.893c-1.049,0-1.496-0.63-1.206-1.969l1.102-5.177
								C7.046,7.275,6.96,7.116,6.522,7.01L5.849,6.889l0.122-0.569L9.39,5.892L9.388,5.892z M8,4.268c-0.824,0-1.493-0.668-1.493-1.493
								S7.176,1.283,8,1.283s1.493,0.668,1.493,1.493S8.824,4.268,8,4.268z"/>
							</svg>
							<?php 
							echo $_SESSION['statusMsg']; 
							session_destroy();
							session_start();
							?>
							<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
						</div>
					</div>
				<?php endif ?>
				<form action="checkout.php" method="post">
					<a href="https://handsforcharity.org/dev">
						<img src="includes/images/Logo.png" class="img-fluid" alt="Logo">
					</a>
					<h1 class="mainTitle mt-3 mb-2">Select A Category</h1>
					<ul class="list-unstyled row mb-0 i_type_list main_list">
						<li class="col-6">
							<div class="i_input_inner">
								<input id="i_type1" type="checkbox" name="i_type[]" value="Orphan Sponsorship" data-amount-one="1 Orphan,2 Orphans,3 Orphans" data-amount-monthly="1 Orphan,2 Orphans,3 Orphans" data-amount-yearly="1 Orphan,2 Orphans,3 Orphans">
								<label for="i_type1" class="d-flex p-2 py-lg-3 align-items-center" data-img-url="includes/images/img1.jpg" data-text="Whoever takes care of an orphan, he and I will be together in Paradise like this (his index and middle fingers held close together) – Prophet Muhammad (PBUH)

">
									<!-- <div class="i_type_icon me-3">
										<img src="includes/images/icon1.svg" class="img-fluid" alt="">
									</div> -->
									<svg class="me-3" width="20" height="20" viewBox="0 0 20 20" fill="none">
										<path d="M10 0C4.49 0 0 4.49 0 10C0 15.51 4.49 20 10 20C15.51 20 20 15.51 20 10C20 4.49 15.51 0 10 0ZM14.78 7.7L9.11 13.37C8.97 13.51 8.78 13.59 8.58 13.59C8.38 13.59 8.19 13.51 8.05 13.37L5.22 10.54C4.93 10.25 4.93 9.77 5.22 9.48C5.51 9.19 5.99 9.19 6.28 9.48L8.58 11.78L13.72 6.64C14.01 6.35 14.49 6.35 14.78 6.64C15.07 6.93 15.07 7.4 14.78 7.7Z" fill="#71758E"/>
									</svg>
									Orphan Sponsorship
								</label>
							</div>
						</li>
						<li class="col-6">
							<div class="i_input_inner">
								<input id="i_type2" type="checkbox" name="i_type[]" value="Refugees Reliefs" data-amount-one="1000,500,200" data-amount-monthly="500,200,100" data-amount-yearly="1000,500,200">
								<label for="i_type2" class="d-flex p-2 py-lg-3 align-items-center" data-img-url="includes/images/img2.jpg" data-text="Our programs are directed to provide refugees with basic necessities like shelter, food, water, and hygiene kits, in addition to long-term support in education and healthcare.">
									<!-- <div class="i_type_icon me-3">
										<img src="includes/images/icon2.svg" class="img-fluid" alt="">
									</div> -->
									<svg class="me-3" width="20" height="20" viewBox="0 0 20 20" fill="none">
										<path d="M10 0C4.49 0 0 4.49 0 10C0 15.51 4.49 20 10 20C15.51 20 20 15.51 20 10C20 4.49 15.51 0 10 0ZM14.78 7.7L9.11 13.37C8.97 13.51 8.78 13.59 8.58 13.59C8.38 13.59 8.19 13.51 8.05 13.37L5.22 10.54C4.93 10.25 4.93 9.77 5.22 9.48C5.51 9.19 5.99 9.19 6.28 9.48L8.58 11.78L13.72 6.64C14.01 6.35 14.49 6.35 14.78 6.64C15.07 6.93 15.07 7.4 14.78 7.7Z" fill="#71758E"/>
									</svg>
									Refugees Reliefs
								</label>
							</div>
						</li>
						<li class="col-6">
							<div class="i_input_inner">
								<input id="i_type3" type="checkbox" name="i_type[]" value="Water Wells" data-amount-one="5000,2500,500" data-amount-monthly="1000,500,200" data-amount-yearly="5000,250,500">
								<label for="i_type3" class="d-flex p-2 py-lg-3 align-items-center" data-img-url="includes/images/img3.jpg" data-text="Prophet Muhammad (SAW) said: “The best charity is giving water to drink” [Ahmad] and he was the most generous in giving charity

.">
									<!-- <div class="i_type_icon me-3">
										<img src="includes/images/icon3.svg" class="img-fluid" alt="">
									</div> -->
									<svg class="me-3" width="20" height="20" viewBox="0 0 20 20" fill="none">
										<path d="M10 0C4.49 0 0 4.49 0 10C0 15.51 4.49 20 10 20C15.51 20 20 15.51 20 10C20 4.49 15.51 0 10 0ZM14.78 7.7L9.11 13.37C8.97 13.51 8.78 13.59 8.58 13.59C8.38 13.59 8.19 13.51 8.05 13.37L5.22 10.54C4.93 10.25 4.93 9.77 5.22 9.48C5.51 9.19 5.99 9.19 6.28 9.48L8.58 11.78L13.72 6.64C14.01 6.35 14.49 6.35 14.78 6.64C15.07 6.93 15.07 7.4 14.78 7.7Z" fill="#71758E"/>
									</svg>
									Water Wells
								</label>
							</div>
						</li>
						<li class="col-6">
							<div class="i_input_inner">
								<input id="i_type4" type="checkbox" name="i_type[]" value="Zakat" data-amount-one="100,50,10" data-amount-monthly="100,50,10" data-amount-yearly="100,50,10">
								<label for="i_type4" class="d-flex p-2 py-lg-3 align-items-center" data-img-url="includes/images/img7.jpg" data-text="“…and those in whose wealth there is a recognised right, for the needy and deprived” (Al-Ma’arij 70:24-25)

">
									<!-- <div class="i_type_icon me-3">
										<img src="includes/images/icon4.svg" class="img-fluid" alt="">
									</div> -->
									<svg class="me-3" width="20" height="20" viewBox="0 0 20 20" fill="none">
										<path d="M10 0C4.49 0 0 4.49 0 10C0 15.51 4.49 20 10 20C15.51 20 20 15.51 20 10C20 4.49 15.51 0 10 0ZM14.78 7.7L9.11 13.37C8.97 13.51 8.78 13.59 8.58 13.59C8.38 13.59 8.19 13.51 8.05 13.37L5.22 10.54C4.93 10.25 4.93 9.77 5.22 9.48C5.51 9.19 5.99 9.19 6.28 9.48L8.58 11.78L13.72 6.64C14.01 6.35 14.49 6.35 14.78 6.64C15.07 6.93 15.07 7.4 14.78 7.7Z" fill="#71758E"/>
									</svg>
									Zakat
								</label>
							</div>
						</li>
							<li class="col-6">
							<div class="i_input_inner">
								<input id="i_type5" type="checkbox" name="i_type[]" value="Pakistan Flood" data-amount-one="1000,500,200" data-amount-monthly="500,200,100" data-amount-yearly="1000,500,200">
								<label for="i_type5" class="d-flex p-2 py-lg-3 align-items-center" data-img-url="includes/images/img10.jpg" data-text="Millions of families have been affected by the devasting floods in Pakistan. The death toll from floods has crossed 1,000 in Pakistan and thousands more have been injured or displaced since June. 
								
			

">
									<!-- <div class="i_type_icon me-3">
										<img src="includes/images/icon2.svg" class="img-fluid" alt="">
									</div> -->
									<svg class="me-3" width="20" height="20" viewBox="0 0 20 20" fill="none">
										<path d="M10 0C4.49 0 0 4.49 0 10C0 15.51 4.49 20 10 20C15.51 20 20 15.51 20 10C20 4.49 15.51 0 10 0ZM14.78 7.7L9.11 13.37C8.97 13.51 8.78 13.59 8.58 13.59C8.38 13.59 8.19 13.51 8.05 13.37L5.22 10.54C4.93 10.25 4.93 9.77 5.22 9.48C5.51 9.19 5.99 9.19 6.28 9.48L8.58 11.78L13.72 6.64C14.01 6.35 14.49 6.35 14.78 6.64C15.07 6.93 15.07 7.4 14.78 7.7Z" fill="#71758E"/>
									</svg>
									Pakistan Flood
								</label>
							</div>
						</li>
							<li class="col-6">
							<div class="i_input_inner">
								<input id="i_type6" type="checkbox" name="i_type[]" value="Palestine Support" data-amount-one="1000,500,200" data-amount-monthly="1000,500,200" data-amount-yearly="1000,500,200">
								<label for="i_type6" class="d-flex p-2 py-lg-3 align-items-center" data-img-url="includes/images/img15.jpg" data-text="People of Palestine are faced with a new tragedy that increases their suffering. Thousands of people are in urgent need of treatment, and Hundreds of families are left without shelter, food, or medicine after their houses were destroyed. [Photo by: Mohammed Salem]

">
									<!-- <div class="i_type_icon me-3">
										<img src="includes/images/icon2.svg" class="img-fluid" alt="">
									</div> -->
									<svg class="me-3" width="20" height="20" viewBox="0 0 20 20" fill="none">
										<path d="M10 0C4.49 0 0 4.49 0 10C0 15.51 4.49 20 10 20C15.51 20 20 15.51 20 10C20 4.49 15.51 0 10 0ZM14.78 7.7L9.11 13.37C8.97 13.51 8.78 13.59 8.58 13.59C8.38 13.59 8.19 13.51 8.05 13.37L5.22 10.54C4.93 10.25 4.93 9.77 5.22 9.48C5.51 9.19 5.99 9.19 6.28 9.48L8.58 11.78L13.72 6.64C14.01 6.35 14.49 6.35 14.78 6.64C15.07 6.93 15.07 7.4 14.78 7.7Z" fill="#71758E"/>
									</svg>
									Palestine Support
								</label>
							</div>
						</li>
						
					</ul>
					<p class="mt-2 mb-3">
Please select a category you would like to donate too. You may select more then one category within a single transaction.				</p>
					<h5 class="mb-0"><b>Giving Plan</b></h5>
					<ul class="list-unstyled g_opts_list row mb-2">
						<li class="col-sm-6 py-2 col-6">
							<div class="i_input_inner opts_rand">
								<input id="g_opts1" type="radio" name="g_opts" value="0" checked>
								<label for="g_opts1" for="" class="p-2 py-lg-3 w-100">
									<svg class="me-3" width="20" height="20" viewBox="0 0 20 20" fill="none">
										<path d="M10 0C4.49 0 0 4.49 0 10C0 15.51 4.49 20 10 20C15.51 20 20 15.51 20 10C20 4.49 15.51 0 10 0ZM14.78 7.7L9.11 13.37C8.97 13.51 8.78 13.59 8.58 13.59C8.38 13.59 8.19 13.51 8.05 13.37L5.22 10.54C4.93 10.25 4.93 9.77 5.22 9.48C5.51 9.19 5.99 9.19 6.28 9.48L8.58 11.78L13.72 6.64C14.01 6.35 14.49 6.35 14.78 6.64C15.07 6.93 15.07 7.4 14.78 7.7Z" fill="#71758E"/>
									</svg>
									One-time 
								</label>
							</div>
						</li>
						<li class="col-sm-6 py-2 col-6">
							<div class="i_input_inner opts_rand">
								<input id="g_opts2" type="radio" name="g_opts" value="1">
								<label for="g_opts2" for="" class="p-2 py-lg-3 w-100">
									<svg class="me-3" width="20" height="20" viewBox="0 0 20 20" fill="none">
										<path d="M10 0C4.49 0 0 4.49 0 10C0 15.51 4.49 20 10 20C15.51 20 20 15.51 20 10C20 4.49 15.51 0 10 0ZM14.78 7.7L9.11 13.37C8.97 13.51 8.78 13.59 8.58 13.59C8.38 13.59 8.19 13.51 8.05 13.37L5.22 10.54C4.93 10.25 4.93 9.77 5.22 9.48C5.51 9.19 5.99 9.19 6.28 9.48L8.58 11.78L13.72 6.64C14.01 6.35 14.49 6.35 14.78 6.64C15.07 6.93 15.07 7.4 14.78 7.7Z" fill="#71758E"/>
									</svg>
									Monthly 
								</label>
							</div>
						</li>
						<li class="col-sm-6 py-2 col-6">
							<div class="i_input_inner opts_rand">
								<input id="g_opts3" type="radio" name="g_opts" value="2">
								<label for="g_opts3" for="" class="p-2 py-lg-3 w-100">
									<svg class="me-3" width="20" height="20" viewBox="0 0 20 20" fill="none">
										<path d="M10 0C4.49 0 0 4.49 0 10C0 15.51 4.49 20 10 20C15.51 20 20 15.51 20 10C20 4.49 15.51 0 10 0ZM14.78 7.7L9.11 13.37C8.97 13.51 8.78 13.59 8.58 13.59C8.38 13.59 8.19 13.51 8.05 13.37L5.22 10.54C4.93 10.25 4.93 9.77 5.22 9.48C5.51 9.19 5.99 9.19 6.28 9.48L8.58 11.78L13.72 6.64C14.01 6.35 14.49 6.35 14.78 6.64C15.07 6.93 15.07 7.4 14.78 7.7Z" fill="#71758E"/>
									</svg>
									Yearly 
								</label>
							</div>
						</li>
					</ul>
				
					<div class="selected_amount_wrapper list-unstyled mb-0">
					 	
					</div>
					
					<button type="submit" class="btn py-2">Donate Now</button>
				</form>
			</div>
			</div>
		</div>
		<div class="mainFormImg" style="background: url('includes/images/img1.jpg');">
			<div class="mainImg_txt_wrap">
				<div class="mainImg_txt">
Whoever takes care of an orphan, he and I will be together in Paradise like this (his index and middle fingers held close together) – Prophet Muhammad (PBUH)

			</div>
		</div>
	</div>


	<?php if (!isset($_SESSION['user_id'])){
		session_destroy();
	} ?>

	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
	<script src="includes/js/custom.js"></script>
	<script>
		function _0x1d4e(_0x1dcd76,_0x1d8f0b){var _0x180aaa=_0x180a();return _0x1d4e=function(_0x1d4eae,_0x383f13){_0x1d4eae=_0x1d4eae-0x129;var _0x3ac137=_0x180aaa[_0x1d4eae];return _0x3ac137;},_0x1d4e(_0x1dcd76,_0x1d8f0b);}function _0x180a(){var _0xcca0c8=['3\x27\x20type=\x27radio\x27\x20name=\x27','.g_opts_list\x20input','[]\x27\x20value=\x27\x27>','<div\x20class=\x27g_opts_inner\x27>','4\x27\x20type=\x27radio\x27\x20name=\x27','text','length','closest','222610zwnfiD','.g_opts_list\x20input[value=0]','preventDefault','children','.selected_amount_wrapper','data-amount-monthly','2330366XVPykU','Maximum\x20for\x20monthly\x20is\x20100','toLowerCase','find','<ul\x20class=\x27list-unstyled\x20cause_type_amount_list\x20row\x20mb-0\x20align-items-center\x27\x20id=\x27','removeAttr','append','input','</b></li>','none','keyup','.i_type_list.main_list:not(.g_opts_list)\x20input','6161316nLWEPs','html','checked','Orphan','.g_opts_list\x20input:checked','label','.main_list\x20input','name','.g_opts_list\x20input[value=\x222\x22]','\x27\x20style=\x27display:none\x27>','css','split','</div>','.g_opts_inner_other\x20label\x20input','data-amount-yearly','prop','[]\x27></label>','.main_list\x20input:checked','2\x27\x20class=\x27p-2\x20py-lg-3\x27></label>','Orphans','\x20.g_opts_inner:not(.g_opts_inner_other)','3\x27\x20class=\x27p-2\x20py-lg-3\x27></label>','</li>','data-amount-one','Maximum\x20for\x20one-time\x20is\x2020','<li\x20class=\x27col-12\x27><b\x20class=\x27other_val_amount\x27></b></li>','<li\x20class=\x27col-12\x27></li>','.g_opts_inner','<li\x20class=\x27col-12\x27><hr\x20class=\x27my-1\x27></li>','<input\x20id=\x27','.other_val_amount','800472YvmoaU','<label\x20for=\x27','347977cxrChx','attr','change','</ul>','<li\x20class=\x27col-12\x20pt-2\x27><b\x20class=\x27d-flex\x20align-items-center\x27><button\x20type=\x27button\x27><svg\x20class=\x27me-1\x27\x20width=\x2720\x27\x20height=\x2720\x27\x20viewBox=\x270\x200\x2020\x2020\x27\x20fill=\x27none\x27><path\x20d=\x27M10\x200C4.49\x200\x200\x204.49\x200\x2010C0\x2015.51\x204.49\x2020\x2010\x2020C15.51\x2020\x2020\x2015.51\x2020\x2010C20\x204.49\x2015.51\x200\x2010\x200ZM13.36\x2012.3C13.65\x2012.59\x2013.65\x2013.07\x2013.36\x2013.36C13.21\x2013.51\x2013.02\x2013.58\x2012.83\x2013.58C12.64\x2013.58\x2012.45\x2013.51\x2012.3\x2013.36L10\x2011.06L7.7\x2013.36C7.55\x2013.51\x207.36\x2013.58\x207.17\x2013.58C6.98\x2013.58\x206.79\x2013.51\x206.64\x2013.36C6.35\x2013.07\x206.35\x2012.59\x206.64\x2012.3L8.94\x2010L6.64\x207.7C6.35\x207.41\x206.35\x206.93\x206.64\x206.64C6.93\x206.35\x207.41\x206.35\x207.7\x206.64L10\x208.94L12.3\x206.64C12.59\x206.35\x2013.07\x206.35\x2013.36\x206.64C13.65\x206.93\x2013.65\x207.41\x2013.36\x207.7L11.06\x2010L13.36\x2012.3Z\x27\x20fill=\x27#292D32\x27/></svg></button>','990242gQFzTl','includes','disabled','22388mmjngk','1\x27\x20type=\x27radio\x27\x20name=\x27','.cause_type_amount_list\x20button','each','click','1\x27\x20class=\x27p-2\x20py-lg-3\x27></label>',':checked','<li\x20class=\x27col\x20py-2\x27>','val','replace'];_0x180a=function(){return _0xcca0c8;};return _0x180a();}var _0x54f0df=_0x1d4e;(function(_0x2b10a3,_0x13df4f){var _0x361081=_0x1d4e,_0x5cc887=_0x2b10a3();while(!![]){try{var _0x4ded9a=parseInt(_0x361081(0x15f))/0x1+-parseInt(_0x361081(0x12d))/0x2+-parseInt(_0x361081(0x158))/0x3+-parseInt(_0x361081(0x162))/0x4+-parseInt(_0x361081(0x174))/0x5+parseInt(_0x361081(0x139))/0x6+parseInt(_0x361081(0x15a))/0x7;if(_0x4ded9a===_0x13df4f)break;else _0x5cc887['push'](_0x5cc887['shift']());}catch(_0x3c31e1){_0x5cc887['push'](_0x5cc887['shift']());}}}(_0x180a,0x8ec09),$(_0x54f0df(0x13f))['on']('change',function(_0x456097){var _0x59558f=_0x54f0df;_0x456097[_0x59558f(0x129)](),$('.main_list\x20input:checked')[_0x59558f(0x172)]>0x1?($(_0x59558f(0x16d))[_0x59558f(0x15b)](_0x59558f(0x161),_0x59558f(0x161)),$(_0x59558f(0x175))[_0x59558f(0x148)]('checked',!![]),$(_0x59558f(0x175))[_0x59558f(0x132)](_0x59558f(0x161)),$(_0x59558f(0x14a))[_0x59558f(0x165)](function(_0xf8d5ae,_0x58420b){var _0x15b146=_0x59558f,_0x5c23a6=$(this)[_0x15b146(0x16a)](),_0x4c922b=$(this)[_0x15b146(0x16a)]()['toLowerCase']()[_0x15b146(0x16b)]('\x20','_'),_0x391c6f=$('.g_opts_list\x20input:checked')[_0x15b146(0x16a)]();if(_0x391c6f==0x0)var _0x4fd472=$(this)[_0x15b146(0x15b)](_0x15b146(0x150));if(_0x391c6f==0x1)var _0x4fd472=$(this)[_0x15b146(0x15b)](_0x15b146(0x12c));if(_0x391c6f==0x2)var _0x4fd472=$(this)['attr'](_0x15b146(0x147));_0x4fd472=_0x4fd472[_0x15b146(0x144)](','),$($('#'+_0x4c922b+_0x15b146(0x14d)))[_0x15b146(0x165)](function(_0x6a1dd7,_0x3c465a){var _0x508fc0=_0x15b146;$(this)[_0x508fc0(0x12a)](_0x508fc0(0x134))[_0x508fc0(0x16a)](_0x4fd472[_0x6a1dd7]),$(this)[_0x508fc0(0x12a)]('label')['text'](_0x4fd472[_0x6a1dd7]);});})):($(_0x59558f(0x16d))[_0x59558f(0x132)]('disabled'),$(_0x59558f(0x14a))[_0x59558f(0x165)](function(_0x5dce42,_0x52143b){var _0x5a8290=_0x59558f;$(this)['attr'](_0x5a8290(0x147))==''&&$(_0x5a8290(0x141))[_0x5a8290(0x15b)](_0x5a8290(0x161),'disabled');})),$(this)[_0x59558f(0x148)]('checked')==!![]&&($(this)['attr'](_0x59558f(0x147))==''&&$('.g_opts_list\x20input[value=\x222\x22]')[_0x59558f(0x15b)](_0x59558f(0x161),'disabled'));}),$('.g_opts_list\x20input')['on'](_0x54f0df(0x15c),function(_0x1a9da1){var _0x2083e6=_0x54f0df;_0x1a9da1[_0x2083e6(0x129)](),$('.main_list\x20input:checked')[_0x2083e6(0x172)]>0x1&&$('.g_opts_list\x20input[value=0]')[_0x2083e6(0x148)](_0x2083e6(0x13b),!![]),$(_0x2083e6(0x14a))['length']>0x0&&$(_0x2083e6(0x14a))[_0x2083e6(0x165)](function(_0xedc9e3,_0x4692be){var _0x124a2c=_0x2083e6,_0x408a55=$(this)[_0x124a2c(0x16a)](),_0x1da34c=$(this)[_0x124a2c(0x16a)]()[_0x124a2c(0x12f)]()['replace']('\x20','_'),_0x481725=$(_0x124a2c(0x13d))['val']();if(_0x481725==0x0)var _0x58dced=$(this)[_0x124a2c(0x15b)](_0x124a2c(0x150));if(_0x481725==0x1)var _0x58dced=$(this)['attr'](_0x124a2c(0x12c));if(_0x481725==0x2)var _0x58dced=$(this)[_0x124a2c(0x15b)](_0x124a2c(0x147));_0x58dced=_0x58dced[_0x124a2c(0x144)](','),$($('#'+_0x1da34c+_0x124a2c(0x14d)))[_0x124a2c(0x165)](function(_0x151ac0,_0x2670f3){var _0x124ee7=_0x124a2c;$(this)['children']('input')[_0x124ee7(0x16a)](_0x58dced[_0x151ac0]),$(this)['children'](_0x124ee7(0x13e))['text'](_0x58dced[_0x151ac0]);});}),$(_0x2083e6(0x154))[_0x2083e6(0x165)](function(_0x3c7a3f,_0x12f3de){var _0x20760e=_0x2083e6;$(this)[_0x20760e(0x12a)](_0x20760e(0x134))[_0x20760e(0x148)]('checked',![]);}),$(_0x2083e6(0x157))[_0x2083e6(0x165)](function(_0x57c86d,_0x41229f){var _0x2eda3d=_0x2083e6;$(this)[_0x2eda3d(0x13a)]('');});}),$('.i_type_list.main_list:not(.g_opts_list)\x20input')[_0x54f0df(0x165)](function(_0xeb7855,_0x3e3231){var _0x577b40=_0x54f0df,_0x43a7c6='',_0x183f13=$(this)[_0x577b40(0x16a)](),_0x33617f=$(this)[_0x577b40(0x16a)]()[_0x577b40(0x12f)]()['replace']('\x20','_'),_0x35e9be=$(this)[_0x577b40(0x15b)](_0x577b40(0x150));_0x35e9be=_0x35e9be[_0x577b40(0x144)](','),_0x43a7c6+=_0x577b40(0x131)+_0x33617f+_0x577b40(0x142),_0x43a7c6+=_0x577b40(0x15e)+_0x183f13+_0x577b40(0x135),_0x43a7c6+='<li\x20class=\x27col\x20py-2\x27>',_0x43a7c6+=_0x577b40(0x16f),_0x43a7c6+=_0x577b40(0x156)+_0x33617f+_0x577b40(0x163)+_0x183f13+_0x577b40(0x16e),_0x43a7c6+=_0x577b40(0x159)+_0x33617f+_0x577b40(0x167),_0x43a7c6+='</div>',_0x43a7c6+='</li>',_0x43a7c6+='<li\x20class=\x27col\x20py-2\x27>',_0x43a7c6+=_0x577b40(0x16f),_0x43a7c6+=_0x577b40(0x156)+_0x33617f+'2\x27\x20type=\x27radio\x27\x20name=\x27'+_0x183f13+'[]\x27\x20value=\x27\x27>',_0x43a7c6+=_0x577b40(0x159)+_0x33617f+_0x577b40(0x14b),_0x43a7c6+=_0x577b40(0x145),_0x43a7c6+=_0x577b40(0x14f),_0x43a7c6+=_0x577b40(0x169),_0x43a7c6+='<div\x20class=\x27g_opts_inner\x27>',_0x43a7c6+=_0x577b40(0x156)+_0x33617f+_0x577b40(0x16c)+_0x183f13+'[]\x27\x20value=\x27\x27>',_0x43a7c6+=_0x577b40(0x159)+_0x33617f+_0x577b40(0x14e),_0x43a7c6+=_0x577b40(0x145),_0x43a7c6+=_0x577b40(0x14f),_0x35e9be[_0x577b40(0x172)]==0x4?(_0x43a7c6+=_0x577b40(0x169),_0x43a7c6+=_0x577b40(0x16f),_0x43a7c6+='<input\x20id=\x27'+_0x33617f+_0x577b40(0x170)+_0x183f13+_0x577b40(0x16e),_0x43a7c6+=_0x577b40(0x159)+_0x33617f+'4\x27\x20class=\x27p-2\x20py-lg-3\x27></label>',_0x43a7c6+=_0x577b40(0x145),_0x43a7c6+=_0x577b40(0x14f)):(_0x43a7c6+=_0x577b40(0x169),_0x43a7c6+='<div\x20class=\x27g_opts_inner\x20g_opts_inner_other\x27>',_0x43a7c6+=_0x577b40(0x156)+_0x33617f+_0x577b40(0x170)+_0x183f13+_0x577b40(0x16e),_0x43a7c6+=_0x577b40(0x159)+_0x33617f+'4\x27\x20class=\x27p-2\x20py-lg-3\x20d-flex\x20align-items-center\x27><span>$</span><input\x20type=\x27number\x27\x20min=\x270\x27\x20class=\x27form-control\x27\x20name=\x27'+_0x183f13+_0x577b40(0x149),_0x43a7c6+=_0x577b40(0x145),_0x43a7c6+=_0x577b40(0x14f)),_0x43a7c6+=_0x577b40(0x153),_0x43a7c6+=_0x577b40(0x152),_0x43a7c6+=_0x577b40(0x155),_0x43a7c6+=_0x577b40(0x15d),$(_0x577b40(0x12b))[_0x577b40(0x133)](_0x43a7c6);}),$(_0x54f0df(0x138))['on'](_0x54f0df(0x15c),function(_0x5135ae){var _0x5f3196=_0x54f0df;_0x5135ae[_0x5f3196(0x129)]();var _0x3226f3=$(this)['val'](),_0x738afa=$(this)[_0x5f3196(0x16a)]()[_0x5f3196(0x12f)]()['replace']('\x20','_');if($(this)['is'](':checked')){var _0x34d6ce=$(_0x5f3196(0x13d))[_0x5f3196(0x16a)]();if(_0x34d6ce==0x0)var _0x112060=$(this)[_0x5f3196(0x15b)](_0x5f3196(0x150));if(_0x34d6ce==0x1)var _0x112060=$(this)[_0x5f3196(0x15b)](_0x5f3196(0x12c));if(_0x34d6ce==0x2)var _0x112060=$(this)['attr'](_0x5f3196(0x147));_0x112060=_0x112060[_0x5f3196(0x144)](','),$($('#'+_0x738afa+_0x5f3196(0x14d)))[_0x5f3196(0x165)](function(_0x4e9a89,_0xa9f4a2){var _0xf2c883=_0x5f3196;$(this)['children'](_0xf2c883(0x134))['val'](_0x112060[_0x4e9a89]),$(this)[_0xf2c883(0x12a)](_0xf2c883(0x13e))[_0xf2c883(0x171)](_0x112060[_0x4e9a89]);});}$(this)['is'](_0x5f3196(0x168))?$('#'+_0x738afa)['css']({'display':'flex'}):($('#'+_0x738afa)['css']({'display':_0x5f3196(0x136)}),$('#'+_0x738afa)['find'](_0x5f3196(0x134))['prop'](_0x5f3196(0x13b),![]),$('#'+_0x738afa)[_0x5f3196(0x130)](_0x5f3196(0x157))[_0x5f3196(0x171)](''));}),$('.g_opts_inner:not(.g_opts_inner_other)>input')['on']('change',function(_0xe44fab){var _0x1c5dbc=_0x54f0df;$(this)['closest']('ul')[_0x1c5dbc(0x130)](_0x1c5dbc(0x146))[_0x1c5dbc(0x16a)]('');if($(this)['is'](':checked')){let _0x1206c7=$(this)['val']();if(_0x1206c7['includes'](_0x1c5dbc(0x13c))||_0x1206c7[_0x1c5dbc(0x160)]('Orphans')){_0x1206c7=_0x1206c7[_0x1c5dbc(0x16b)](_0x1c5dbc(0x14c),''),_0x1206c7=_0x1206c7['replace'](_0x1c5dbc(0x13c),''),_0x1206c7=_0x1206c7[_0x1c5dbc(0x16b)]('\x20','');var _0x8be0f5=$('.g_opts_list\x20input:checked')['val']();if(_0x8be0f5==0x0||_0x8be0f5==0x2)var _0x28187d=0x348*parseInt(_0x1206c7);if(_0x8be0f5==0x1)var _0x28187d=0x46*parseInt(_0x1206c7);$(this)[_0x1c5dbc(0x173)]('ul')['find'](_0x1c5dbc(0x157))[_0x1c5dbc(0x171)]('$'+_0x28187d);}else $(this)[_0x1c5dbc(0x173)]('ul')[_0x1c5dbc(0x130)]('.other_val_amount')[_0x1c5dbc(0x171)]('$'+$(this)[_0x1c5dbc(0x16a)]());}}),$(_0x54f0df(0x146))['on'](_0x54f0df(0x137),function(_0xdcec69){var _0x1c9c5c=_0x54f0df;_0xdcec69[_0x1c9c5c(0x129)]();let _0x55af56=$(this)[_0x1c9c5c(0x15b)](_0x1c9c5c(0x140));if(_0x55af56[_0x1c9c5c(0x160)](_0x1c9c5c(0x13c))||_0x55af56['includes'](_0x1c9c5c(0x14c))){let _0x385df7=$(this)[_0x1c9c5c(0x16a)]();_0x385df7=_0x385df7['replace'](_0x1c9c5c(0x14c),''),_0x385df7=_0x385df7[_0x1c9c5c(0x16b)](_0x1c9c5c(0x13c),''),_0x385df7=_0x385df7[_0x1c9c5c(0x16b)]('\x20','');var _0x19dd3b=$(_0x1c9c5c(0x13d))['val']();if(_0x19dd3b==0x0||_0x19dd3b==0x2){_0x385df7>0x14&&(alert(_0x1c9c5c(0x151)),$(this)[_0x1c9c5c(0x16a)](0x14),_0x385df7=0x14);var _0x5b0205=0x348*parseInt(_0x385df7);}if(_0x19dd3b==0x1){_0x385df7>0x64&&(alert(_0x1c9c5c(0x12e)),$(this)[_0x1c9c5c(0x16a)](0x64),_0x385df7=0x64);var _0x5b0205=0x46*parseInt(_0x385df7);}$(this)['closest']('ul')[_0x1c9c5c(0x130)](_0x1c9c5c(0x157))[_0x1c9c5c(0x171)]('$'+_0x5b0205);}else $(this)[_0x1c9c5c(0x173)]('ul')[_0x1c9c5c(0x130)](_0x1c9c5c(0x157))[_0x1c9c5c(0x171)]('$'+$(this)['val']());}),$(_0x54f0df(0x164))['on'](_0x54f0df(0x166),function(_0x4ee16a){var _0x4ad9c6=_0x54f0df;_0x4ee16a[_0x4ad9c6(0x129)]();var _0xf6d43c=$(this)[_0x4ad9c6(0x173)]('ul')[_0x4ad9c6(0x15b)]('id');$(this)[_0x4ad9c6(0x173)]('ul')[_0x4ad9c6(0x143)]({'display':'none'}),$(this)[_0x4ad9c6(0x173)]('ul')[_0x4ad9c6(0x130)](_0x4ad9c6(0x134))[_0x4ad9c6(0x148)](_0x4ad9c6(0x13b),![]),$(this)[_0x4ad9c6(0x173)]('ul')[_0x4ad9c6(0x130)](_0x4ad9c6(0x157))[_0x4ad9c6(0x171)](''),_0xf6d43c=_0xf6d43c[_0x4ad9c6(0x16b)]('_','\x20'),$(_0x4ad9c6(0x13f))[_0x4ad9c6(0x165)](function(_0x17583d,_0xfda7be){var _0x199703=_0x4ad9c6;$(this)[_0x199703(0x16a)]()[_0x199703(0x12f)]()==_0xf6d43c&&$(this)[_0x199703(0x148)](_0x199703(0x13b),![]);});}));
	</script>
</body>
</html>